const business = {
  name: 'Torres Compra Cash',
  email: 'info@torrescompracash.com',
  phoneDisplay: '(787) 000-0000',
  phoneDigits: '17870000000',
  whatsappMessage: 'Hola, quiero recibir una oferta cash para mi propiedad en Puerto Rico.',
  messengerUrl: 'https://m.me/torrescompracash',
  areas: ['San Juan', 'Carolina', 'Caguas', 'Bayamón', 'Ponce', 'Arecibo'],
  formAction: 'https://formspree.io/f/your-form-id',
};

const whatsappUrl = `https://wa.me/${business.phoneDigits}?text=${encodeURIComponent(business.whatsappMessage)}`;

const benefits = [
  'Ofertas cash',
  'Cerramos rápido',
  'Compramos en cualquier condición',
  'Proceso simple y directo',
];

const situations = [
  'Propiedades con reparaciones',
  'Herencias',
  'Mudanza o urgencia',
  'Pagos atrasados',
  'No quieres listar con realtor',
  'Necesitas vender sin complicaciones',
];

const steps = [
  { title: 'Cuéntanos sobre la propiedad', text: 'Envíanos la dirección, fotos y algunos detalles básicos.' },
  { title: 'Evaluamos tu caso', text: 'Revisamos la propiedad y la situación para presentarte una opción.' },
  { title: 'Recibes una oferta cash', text: 'Te presentamos una oferta y te explicamos el proceso con claridad.' },
  { title: 'Cerramos rápido', text: 'Si te conviene, coordinamos el cierre lo antes posible.' },
];

const faqs = [
  { q: '¿Compran casas en cualquier condición?', a: 'Sí. Evaluamos propiedades en distintas condiciones, incluyendo casas que necesitan reparaciones.' },
  { q: '¿Tengo que hacer arreglos antes de vender?', a: 'No necesariamente. Podemos evaluar la propiedad tal y como está.' },
  { q: '¿Qué información necesitan para empezar?', a: 'Dirección, condición general, fotos si las tienes, y tu situación o meta de venta.' },
];

export default function HomePage() {
  return (
    <main className="site">
      <header className="topbar">
        <div>
          <div className="brand">{business.name}</div>
          <div className="subbrand">Wholesaling Real Estate • Puerto Rico</div>
        </div>
        <div className="topbar-actions">
          <a href={whatsappUrl} target="_blank" rel="noreferrer" className="btn btn-secondary">WhatsApp</a>
          <a href="#contacto" className="btn btn-primary">Solicita tu oferta</a>
        </div>
      </header>

      <section className="hero">
        <div className="hero-copy">
          <div className="badge">Oferta cash • Cierre rápido • Puerto Rico</div>
          <h1>¿Necesitas vender tu casa <span>rápido</span>?</h1>
          <p>
            En {business.name} evaluamos propiedades en cualquier condición y te orientamos sobre una posible oferta cash
            sin vueltas ni procesos largos.
          </p>
          <div className="actions">
            <a href="#contacto" className="btn btn-primary">Quiero una oferta cash</a>
            <a href={whatsappUrl} target="_blank" rel="noreferrer" className="btn btn-secondary">Escríbenos por WhatsApp</a>
            <a href={business.messengerUrl} target="_blank" rel="noreferrer" className="btn btn-secondary">Abrir Messenger</a>
          </div>
          <div className="areas">Áreas comunes: {business.areas.join(' • ')}</div>
          <div className="mini-grid">
            <div className="mini-card"><strong>Sin presión</strong><span>Orientación clara</span></div>
            <div className="mini-card"><strong>Proceso simple</strong><span>Habla directo</span></div>
            <div className="mini-card"><strong>Respuesta rápida</strong><span>WhatsApp y Messenger</span></div>
          </div>
          <div className="benefits">
            {benefits.map((item) => <div key={item} className="pill">✓ {item}</div>)}
          </div>
        </div>

        <div className="hero-form card">
          <div className="eyebrow">Recibe orientación</div>
          <h2>Solicita una evaluación rápida</h2>
          <p>Completa el formulario o escríbenos directo por WhatsApp.</p>
          <form action={business.formAction} method="POST" className="form">
            <input type="hidden" name="_subject" value="Nuevo lead - Torres Compra Cash" />
            <input type="hidden" name="source" value="website" />
            <input name="name" required placeholder="Nombre" />
            <input name="phone" required placeholder="Teléfono" />
            <input name="propertyLocation" required placeholder="Pueblo o dirección de la propiedad" />
            <textarea name="details" required placeholder="Condición de la propiedad y situación" rows={5} />
            <button type="submit" className="btn btn-accent btn-block">Quiero mi oferta</button>
            <div className="split-actions">
              <a href={whatsappUrl} target="_blank" rel="noreferrer" className="btn btn-secondary">Hablar por WhatsApp</a>
              <a href={business.messengerUrl} target="_blank" rel="noreferrer" className="btn btn-secondary">Hablar por Messenger</a>
            </div>
            <small>Cambia <b>formAction</b> por tu endpoint de Formspree para recibir leads reales.</small>
          </form>
        </div>
      </section>

      <section className="stats-grid">
        <div className="card"><h3>Cash</h3><p>Alternativa directa para dueños que quieren una opción rápida.</p></div>
        <div className="card"><h3>Rápido</h3><p>Proceso simple para personas que no quieren perder tiempo.</p></div>
        <div className="card"><h3>Flexible</h3><p>Evaluamos diferentes tipos de propiedades y situaciones.</p></div>
        <div className="card card-highlight"><h4>Prueba social</h4><p>Añade aquí testimonios reales, cierres o capturas de conversaciones.</p></div>
      </section>

      <section className="section">
        <div className="section-head">
          <div className="eyebrow">Situaciones comunes</div>
          <h2>Podemos evaluar propiedades en escenarios como estos</h2>
          <p>No todas las ventas son iguales. Por eso buscamos entender tu caso antes de presentarte una opción.</p>
        </div>
        <div className="grid-3">
          {situations.map((item) => (
            <div key={item} className="card">
              <h3>{item}</h3>
              <p>Cuéntanos tu situación y vemos si podemos ayudarte con una alternativa clara y directa.</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section section-muted">
        <div className="section-head">
          <div className="eyebrow accent">Proceso</div>
          <h2>Así funciona</h2>
          <p>Un proceso sencillo pensado para moverte rápido.</p>
        </div>
        <div className="grid-4">
          {steps.map((step, idx) => (
            <div key={step.title} className="card step-card">
              <div className="step-num">{idx + 1}</div>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="section grid-2">
        <div className="card card-gradient">
          <div className="eyebrow">Por qué elegirnos</div>
          <h2>Comunicación clara y enfoque directo</h2>
          <p>
            Sabemos que vender una propiedad puede sentirse pesado. Nuestro objetivo es darte claridad, rapidez y una
            conversación sencilla desde el principio.
          </p>
          <ul className="checks">
            <li>✓ Respuesta rápida</li>
            <li>✓ Evaluación sencilla</li>
            <li>✓ Orientación sin compromiso</li>
          </ul>
        </div>
        <div className="card">
          <div className="eyebrow accent">FAQ</div>
          <div className="faq-list">
            {faqs.map((item) => (
              <div key={item.q} className="faq-item">
                <h3>{item.q}</h3>
                <p>{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="section">
        <div className="grid-3 testimonials">
          <div className="card">
            <div className="eyebrow accent">Señales de confianza</div>
            <h3>Sección ideal para Facebook Ads</h3>
            <p>Aquí puedes colocar cierres, testimonios cortos, cantidad de propiedades evaluadas o pueblos trabajados.</p>
          </div>
          <div className="card">
            <h3>Testimonio #1</h3>
            <p>“El proceso fue claro y rápido. Pudimos hablar directo y resolver.”</p>
          </div>
          <div className="card">
            <h3>Testimonio #2</h3>
            <p>“Me orientaron sin presión y contestaron rápido por WhatsApp.”</p>
          </div>
        </div>
      </section>

      <section id="contacto" className="section contact-section">
        <div className="contact-shell">
          <div>
            <div className="eyebrow">Hablemos</div>
            <h2>Solicita tu evaluación hoy</h2>
            <p>Si estás pensando vender una propiedad en Puerto Rico, envíanos tu información. Te orientamos sin compromiso.</p>
          </div>
          <div className="card compact-contact">
            <div><small>Email</small><strong>{business.email}</strong></div>
            <div><small>Teléfono</small><strong>{business.phoneDisplay}</strong></div>
            <div><small>Horario</small><strong>Lunes a Sábado</strong></div>
            <a href={whatsappUrl} target="_blank" rel="noreferrer" className="btn btn-accent btn-block">WhatsApp ahora</a>
            <a href={business.messengerUrl} target="_blank" rel="noreferrer" className="btn btn-secondary btn-block">Messenger</a>
          </div>
        </div>
      </section>

      <div className="mobile-bar">
        <a href={whatsappUrl} target="_blank" rel="noreferrer" className="btn btn-accent">WhatsApp</a>
        <a href="#contacto" className="btn btn-primary">Oferta</a>
      </div>

      <footer className="footer">
        <div>© 2026 {business.name}. Todos los derechos reservados.</div>
        <div>Wholesaling Real Estate • Puerto Rico</div>
      </footer>
    </main>
  );
}
